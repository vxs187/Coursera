/* Add Author and Project Details here */
Author: Visweshwar Srinivasan
Project Details: There are three Files included: stats.h, stats.c
                 and the README.md. The stats.h is the header file,
                 stats.c is the C-script and the README file gives
                 information about the project. 
